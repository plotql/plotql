# say.js
installation: `$ npm install say.js`
------
## Development
```
> say = require('say.js').dev
```

## Production
```
> say = require('say.js').prod
```

### Usage
```
coffee> say "hello" 
```
