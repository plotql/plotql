exports.dev = require('./say').dev
exports.prod = require('./say').prod
