
0.0.3 / 2012-10-15 
==================

  * package: added `component` namespace (fixes #1)

0.0.2 / 2012-09-20 
==================

  * add code smell to `.merge()`
